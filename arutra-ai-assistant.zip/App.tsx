
import React, { useState, useEffect } from 'react';
import { View, Reminder } from './types';
import Sidebar from './components/Sidebar';
import ConversationView from './components/ConversationView';
import ImageGenView from './components/ImageGenView';
import VideoGenView from './components/VideoGenView';
import RemindersView from './components/RemindersView';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.CONVERSATION);
  const [reminders, setReminders] = useState<Reminder[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('arutra_reminders');
    if (saved) setReminders(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('arutra_reminders', JSON.stringify(reminders));
  }, [reminders]);

  const addReminder = (text: string) => {
    const newReminder: Reminder = {
      id: Date.now().toString(),
      text,
      timestamp: Date.now(),
      completed: false
    };
    setReminders(prev => [newReminder, ...prev]);
    return "Reminder added successfully.";
  };

  const toggleReminder = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  };

  const deleteReminder = (id: string) => {
    setReminders(prev => prev.filter(r => r.id !== id));
  };

  const renderView = () => {
    switch (activeView) {
      case View.CONVERSATION:
        return <ConversationView onAddReminder={addReminder} />;
      case View.IMAGE_GEN:
        return <ImageGenView />;
      case View.VIDEO_GEN:
        return <VideoGenView />;
      case View.REMINDERS:
        return <RemindersView reminders={reminders} onToggle={toggleReminder} onDelete={deleteReminder} />;
      default:
        return <ConversationView onAddReminder={addReminder} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      <Sidebar activeView={activeView} onViewChange={setActiveView} reminderCount={reminders.filter(r => !r.completed).length} />
      <main className="flex-1 relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/40 via-slate-950 to-slate-950">
        {renderView()}
      </main>
    </div>
  );
};

export default App;
