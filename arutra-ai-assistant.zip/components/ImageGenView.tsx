
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { ImageResult } from '../types';

const ImageGenView: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [results, setResults] = useState<ImageResult[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16' | '4:3'>('1:1');

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setPrompt(prev => prev + (prev ? ' ' : '') + transcript);
    };
    recognition.start();
  };

  const generateImage = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio,
          }
        }
      });

      let imageUrl = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setResults(prev => [{
          id: Date.now().toString(),
          url: imageUrl,
          prompt: prompt,
        }, ...prev]);
        setPrompt('');
      }
    } catch (error) {
      console.error(error);
      alert('Failed to generate image.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-8 overflow-y-auto bg-slate-950">
      <div className="max-w-4xl mx-auto w-full space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-outfit font-bold text-white">Image Creator</h2>
          <p className="text-slate-400">Describe what's in your mind and let Nexus bring it to life.</p>
        </div>

        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 shadow-xl backdrop-blur-sm space-y-6">
          <div className="space-y-4 relative">
            <div className="flex justify-between items-center ml-1">
              <label className="text-sm font-semibold text-slate-300">Your Prompt</label>
              <button 
                onClick={toggleListening}
                className={`flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-bold transition-all ${isListening ? 'bg-rose-500/20 text-rose-500 animate-pulse' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                {isListening ? 'Listening...' : 'Voice Input'}
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A futuristic cyber-city with neon lights, cinematic lighting, 8k resolution..."
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-slate-100 h-32 focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all resize-none shadow-inner"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
              {(['1:1', '16:9', '9:16', '4:3'] as const).map((ratio) => (
                <button
                  key={ratio}
                  onClick={() => setAspectRatio(ratio)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                    aspectRatio === ratio 
                      ? 'bg-indigo-600 text-white shadow-lg' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {ratio}
                </button>
              ))}
            </div>

            <button
              onClick={generateImage}
              disabled={!prompt.trim() || isGenerating}
              className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-bold rounded-xl shadow-lg flex items-center gap-2 transition-all active:scale-95"
            >
              {isGenerating ? 'Forging...' : 'Generate Magic'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pb-12">
          {results.map((img) => (
            <div key={img.id} className="group relative bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl transition-all hover:-translate-y-1">
              <img src={img.url} alt={img.prompt} className="w-full h-auto object-cover aspect-square" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                <p className="text-white text-sm line-clamp-2 bg-slate-950/60 backdrop-blur-md p-3 rounded-xl border border-slate-700/50">{img.prompt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImageGenView;
