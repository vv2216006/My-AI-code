
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Blob as GenAIBlob, Type } from '@google/genai';

interface ConversationViewProps {
  onAddReminder: (text: string) => string;
}

const ConversationView: React.FC<ConversationViewProps> = ({ onAddReminder }) => {
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [status, setStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [lastUserText, setLastUserText] = useState('');
  const [lastAiText, setLastAiText] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<any>(null);

  // Audio helper functions
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const toolDefinitions = [
    {
      name: 'add_reminder',
      parameters: {
        type: Type.OBJECT,
        description: 'Add a new reminder or task to the list.',
        properties: {
          text: { type: Type.STRING, description: 'The task description' },
        },
        required: ['text'],
      },
    },
    {
      name: 'open_website',
      parameters: {
        type: Type.OBJECT,
        description: 'Open a specific website or search service.',
        properties: {
          url: { type: Type.STRING, description: 'The full URL to open' },
          name: { type: Type.STRING, description: 'Friendly name of the site' },
        },
        required: ['url', 'name'],
      },
    }
  ];

  const handleToolCall = (fc: any) => {
    try {
      if (fc.name === 'add_reminder') {
        onAddReminder(fc.args.text);
        return `I've added the reminder: ${fc.args.text}`;
      }
      if (fc.name === 'open_website') {
        window.open(fc.args.url, '_blank');
        return `Successfully opened ${fc.args.name}`;
      }
      return "Action completed.";
    } catch (e) {
      return "I encountered an error trying to perform that action.";
    }
  };

  const startSession = async () => {
    try {
      setStatus('listening');
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            console.log("Arutra Online");
            setIsActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: GenAIBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setLastAiText(message.serverContent.outputTranscription.text);
            } else if (message.serverContent?.inputTranscription) {
              setLastUserText(message.serverContent.inputTranscription.text);
            }

            if (message.toolCall) {
              setStatus('thinking');
              for (const fc of message.toolCall.functionCalls) {
                const result = handleToolCall(fc);
                sessionPromise.then(session => session.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result } }
                }));
              }
            }

            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              setStatus('speaking');
              const ctx = audioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setStatus('listening');
              };
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setStatus('listening');
            }
          },
          onclose: () => {
            setIsActive(false);
            setStatus('idle');
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: 'You are Arutra, a sophisticated AI assistant. You interact solely through voice like an Alexa device. Be helpful, direct, and slightly futuristic. Use tools to manage tasks and open sites.',
          tools: [{ functionDeclarations: toolDefinitions }],
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Session fail:", err);
      alert("Microphone is required for Arutra to listen.");
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    setIsActive(false);
    setStatus('idle');
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-transparent">
      <div className="relative w-full max-w-2xl flex flex-col items-center">
        
        {/* The Arutra Core Orb */}
        <div className="relative mb-16">
          <div className={`absolute inset-0 -m-16 rounded-full blur-[80px] transition-all duration-1000 ${
            status === 'listening' ? 'bg-rose-500/20 scale-110' :
            status === 'thinking' ? 'bg-indigo-500/30 scale-125' :
            status === 'speaking' ? 'bg-emerald-500/20 scale-110' : 'bg-indigo-500/10 scale-90'
          }`}></div>
          
          <div className={`w-48 h-48 rounded-full flex items-center justify-center shadow-2xl relative z-10 transition-all duration-700 animate-orb ${
            isActive ? 'bg-slate-900 ring-4 ring-white/5' : 'bg-slate-900 border border-slate-800'
          }`}>
            <div className={`absolute inset-0 rounded-full bg-gradient-to-br transition-opacity duration-700 ${
              status === 'listening' ? 'from-rose-500/40 to-rose-900/40 opacity-100' :
              status === 'thinking' ? 'from-indigo-500/40 to-indigo-900/40 opacity-100' :
              status === 'speaking' ? 'from-emerald-500/40 to-emerald-900/40 opacity-100' : 'from-indigo-500/20 to-indigo-900/20 opacity-40'
            }`}></div>
            
            {status !== 'idle' ? (
              <div className="flex gap-2 h-16 items-center z-20">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div 
                    key={i} 
                    className={`w-2 rounded-full bg-white transition-all duration-300 ${status === 'listening' ? 'animate-pulse' : 'animate-bounce'}`}
                    style={{ height: `${20 + Math.random() * 60}%`, animationDelay: `${i * 0.1}s` }}
                  ></div>
                ))}
              </div>
            ) : (
              <div className="text-indigo-400 font-outfit text-6xl font-bold z-20">A</div>
            )}
          </div>
        </div>

        {/* HUD Information */}
        <div className="space-y-6 min-h-[160px] flex flex-col items-center justify-center">
          <div className="space-y-2">
            <h2 className="text-5xl font-outfit font-bold text-white tracking-tight">
              {status === 'idle' ? 'Arutra' : status === 'listening' ? 'Listening...' : status === 'thinking' ? 'Processing...' : 'Speaking...'}
            </h2>
            <p className="text-slate-400 text-lg">
              {status === 'idle' ? 'Voice Intelligence Protocol Ready' : 'Direct neural connection active'}
            </p>
          </div>

          <div className="max-w-md w-full">
            {lastUserText && (
              <p className="text-indigo-300/80 italic text-sm mb-2 animate-in fade-in slide-in-from-bottom-2">
                &ldquo;{lastUserText}&rdquo;
              </p>
            )}
            {lastAiText && (
              <p className="text-white font-medium text-base animate-in fade-in slide-in-from-bottom-1">
                {lastAiText}
              </p>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="mt-12 flex items-center gap-6">
          {!isActive ? (
            <button 
              onClick={startSession}
              className="px-12 py-5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-2xl shadow-indigo-500/20 transition-all active:scale-95 text-lg"
            >
              Wake Arutra
            </button>
          ) : (
            <div className="flex gap-4">
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-all ${
                  isMuted ? 'bg-rose-500 border-rose-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                }`}
                title={isMuted ? "Unmute Mic" : "Mute Mic"}
              >
                {isMuted ? (
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                ) : (
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                )}
              </button>
              <button 
                onClick={stopSession}
                className="px-10 py-5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-2xl border border-slate-700 transition-all active:scale-95"
              >
                Sleep
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ConversationView;
