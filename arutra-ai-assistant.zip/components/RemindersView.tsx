
import React from 'react';
import { Reminder } from '../types';

interface RemindersViewProps {
  reminders: Reminder[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const RemindersView: React.FC<RemindersViewProps> = ({ reminders, onToggle, onDelete }) => {
  return (
    <div className="h-full flex flex-col bg-slate-950 p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto w-full space-y-10">
        <div className="space-y-2">
          <h2 className="text-4xl font-outfit font-bold text-white">Task Center</h2>
          <p className="text-slate-400">Manage your AI-generated reminders and productivity log.</p>
        </div>

        {reminders.length === 0 ? (
          <div className="bg-slate-900/50 border border-slate-800 rounded-[2.5rem] p-16 text-center space-y-4">
            <div className="w-20 h-20 bg-slate-800 rounded-3xl flex items-center justify-center mx-auto text-slate-600">
               <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
            </div>
            <p className="text-slate-500 text-lg">Your workspace is clear. Ask Nexus to add a reminder to get started.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {reminders.map((r) => (
              <div key={r.id} className={`group flex items-center gap-4 p-5 rounded-3xl border transition-all ${
                r.completed 
                  ? 'bg-slate-900/30 border-slate-800/50 opacity-60' 
                  : 'bg-slate-900 border-slate-800 hover:border-indigo-500/50 hover:shadow-[0_0_20px_rgba(79,70,229,0.05)]'
              }`}>
                <button 
                  onClick={() => onToggle(r.id)}
                  className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-colors ${
                    r.completed ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-700 hover:border-indigo-500'
                  }`}
                >
                  {r.completed && <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>}
                </button>
                
                <div className="flex-1">
                  <p className={`text-lg transition-all ${r.completed ? 'line-through text-slate-600' : 'text-slate-200'}`}>
                    {r.text}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {new Date(r.timestamp).toLocaleString()}
                  </p>
                </div>

                <button 
                  onClick={() => onDelete(r.id)}
                  className="p-3 text-slate-600 hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RemindersView;
