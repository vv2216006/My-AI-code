
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { VideoResult } from '../types';

const VideoGenView: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [results, setResults] = useState<VideoResult[]>([]);
  const [statusMessage, setStatusMessage] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    try {
      const hasKey = await (window as any).aistudio.hasSelectedApiKey();
      setHasApiKey(hasKey);
    } catch (e) {
      console.warn("AI Studio key check failed", e);
    }
  };

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setPrompt(prev => prev + (prev ? ' ' : '') + transcript);
    };
    recognition.start();
  };

  const handleOpenKeyDialog = async () => {
    try {
      await (window as any).aistudio.openSelectKey();
      setHasApiKey(true);
    } catch (e) {
      console.error("Failed to open key dialog", e);
    }
  };

  const loadingMessages = [
    "Initializing neural dreamweaver...",
    "Rendering temporal dimensions...",
    "Consulting the cinematic architects...",
    "Synthesizing motion vectors..."
  ];

  const generateVideo = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    let messageIndex = 0;
    setStatusMessage(loadingMessages[0]);

    const intervalId = setInterval(() => {
      messageIndex = (messageIndex + 1) % loadingMessages.length;
      setStatusMessage(loadingMessages[messageIndex]);
    }, 8000);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await videoResponse.blob();
        const videoUrl = URL.createObjectURL(blob);

        setResults(prev => [{
          id: Date.now().toString(),
          url: videoUrl,
          prompt: prompt
        }, ...prev]);
        setPrompt('');
      }
    } catch (error: any) {
      console.error(error);
      alert("Video generation failed.");
    } finally {
      setIsGenerating(false);
      clearInterval(intervalId);
    }
  };

  if (!hasApiKey) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-slate-950 text-center">
        <div className="max-w-md space-y-8">
          <div className="w-20 h-20 bg-indigo-600/20 rounded-full flex items-center justify-center mx-auto">
            <svg className="w-10 h-10 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
          </div>
          <div className="space-y-3">
            <h2 className="text-3xl font-outfit font-bold text-white">Video Studio Access</h2>
            <p className="text-slate-400">Veo generation requires a personal API key. Please select one to proceed.</p>
          </div>
          <button 
            onClick={handleOpenKeyDialog}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-xl transition-all"
          >
            Select API Key
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col p-8 bg-slate-950 overflow-y-auto">
      <div className="max-w-5xl mx-auto w-full space-y-12">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <h2 className="text-4xl font-outfit font-bold text-white">Cinematic Studio</h2>
            <p className="text-slate-400">Generate high-fidelity AI video powered by Veo 3.1</p>
          </div>
          <button onClick={toggleListening} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            {isListening ? 'Listening...' : 'Voice Command'}
          </button>
        </div>

        {!isGenerating ? (
          <div className="bg-slate-900/50 p-8 rounded-[2rem] border border-slate-800 shadow-2xl space-y-8 backdrop-blur-sm">
            <div className="space-y-4">
              <label className="text-sm font-bold text-slate-400 uppercase tracking-widest ml-1">The Scene Description</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={isListening ? "Listening to your vision..." : "A drone shot flying over a volcanic landscape..."}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-6 text-lg text-slate-100 h-40 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500/50 transition-all resize-none shadow-inner"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={generateVideo}
                disabled={!prompt.trim() || isGenerating}
                className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-2xl shadow-indigo-500/20 flex items-center gap-3 transition-all active:scale-95"
              >
                Render Sequence
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900/50 p-12 rounded-[2rem] border border-indigo-500/20 shadow-2xl flex flex-col items-center justify-center space-y-8">
            <div className="w-24 h-24 border-4 border-slate-800 border-t-indigo-500 rounded-full animate-spin"></div>
            <div className="text-center space-y-3">
              <h3 className="text-2xl font-outfit font-bold text-white">{statusMessage}</h3>
              <p className="text-slate-500 max-w-sm">Generating high-fidelity video can take up to 2 minutes.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 gap-12 pb-24">
          {results.map((video) => (
            <div key={video.id} className="bg-slate-900 rounded-[2.5rem] overflow-hidden border border-slate-800 shadow-2xl">
              <video src={video.url} controls className="w-full aspect-video bg-black" />
              <div className="p-8">
                <p className="text-slate-300 text-lg italic leading-relaxed">"{video.prompt}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VideoGenView;
