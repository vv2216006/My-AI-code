
// This file is deprecated and can be removed.
// Arutra uses ConversationView for Alexa-style interactions.
export default () => null;
