
export enum View {
  CONVERSATION = 'conversation',
  IMAGE_GEN = 'image_gen',
  VIDEO_GEN = 'video_gen',
  REMINDERS = 'reminders'
}

export interface Reminder {
  id: string;
  text: string;
  timestamp: number;
  completed: boolean;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  images?: string[];
  groundingUrls?: Array<{ title: string; uri: string }>;
  toolCall?: {
    name: string;
    args: any;
    status: 'executing' | 'success' | 'failed';
  };
  timestamp: number;
}

export interface ImageResult {
  id: string;
  url: string;
  prompt: string;
}

export interface VideoResult {
  id: string;
  url: string;
  prompt: string;
}
